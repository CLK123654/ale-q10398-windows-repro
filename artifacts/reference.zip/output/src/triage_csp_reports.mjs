import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

const inputRoot = path.resolve(process.argv[2] ?? '.');
const outputRoot = path.resolve(process.argv[3] ?? path.join(inputRoot, 'output'));

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function readJson(relativePath) {
  return JSON.parse(await fs.readFile(path.join(inputRoot, relativePath), 'utf8'));
}

function csvCell(value) {
  const text = String(value ?? '');
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function toCsv(headers, rows) {
  return `${headers.join(',')}\n${rows.map((row) => headers.map((header) => csvCell(row[header])).join(',')).join('\n')}\n`;
}

function blockedHostOrToken(blockedUri) {
  try {
    const parsed = new URL(blockedUri);
    return parsed.host || blockedUri;
  } catch {
    return blockedUri;
  }
}

function normalizedDocumentPath(documentUri) {
  try {
    return new URL(documentUri).pathname || '/';
  } catch {
    return String(documentUri).split('?')[0];
  }
}

function buildFingerprint(context, policy) {
  const digest = policy.fingerprint_digest;
  const parts = policy.duplicate_fingerprint_fields.map((field) => String(context[field] ?? ''));
  return crypto.createHash(digest.algorithm)
    .update(parts.join(digest.separator))
    .digest('hex')
    .slice(0, digest.hex_chars);
}

async function loadSourceMappings(releaseArtifacts) {
  const mappings = new Map();
  for (const [releaseId, release] of Object.entries(releaseArtifacts.releases)) {
    for (const [sourceFile, relativePath] of Object.entries(release.source_maps)) {
      const map = await readJson(relativePath);
      assert(map.file === sourceFile, `source map文件声明不符：${relativePath}`);
      for (const item of map.mappings) {
        mappings.set(`${releaseId}\0${sourceFile}\0${item.line}\0${item.column}`, item);
      }
    }
  }
  return mappings;
}

function ownerFor(sourcePath, policy) {
  const matches = Object.entries(policy.owner_by_source_prefix)
    .filter(([prefix]) => sourcePath.startsWith(prefix))
    .sort(([left], [right]) => right.length - left.length);
  return matches[0]?.[1] ?? policy.default_owner;
}

const policy = await readJson('rules/csp_triage_policy.json');
const releaseArtifacts = await readJson('config/release_artifacts.json');
const sourceMappings = await loadSourceMappings(releaseArtifacts);
assert(policy.duplicate_fingerprint_fields.length > 0, 'duplicate_fingerprint_fields不能为空');
assert(new Set(policy.suppression_reason_order).size === policy.suppression_reason_order.length, 'suppression_reason_order不得重复');
assert(policy.fingerprint_digest.hex_chars > 0, 'fingerprint摘要长度必须为正数');

const rawLines = (await fs.readFile(path.join(inputRoot, 'data', 'csp_reports.jsonl'), 'utf8')).split(/\r?\n/);
const normalizedRows = [];
const sourceRows = [];
const suppressedRows = [];
const seenFingerprints = new Map();

for (let index = 0; index < rawLines.length; index += 1) {
  const rawLine = rawLines[index];
  const lineNo = index + 1;
  if (!rawLine.trim()) continue;
  let report;
  try {
    report = JSON.parse(rawLine);
  } catch {
    suppressedRows.push({ line_no: lineNo, report_id: '', reason: 'malformed_json', detail: 'JSON.parse failed' });
    continue;
  }

  const received = Date.parse(report.received_at_utc);
  const blockedHost = blockedHostOrToken(report.blocked_uri);
  const documentPath = normalizedDocumentPath(report.document_uri);
  const fingerprintContext = { ...report, document_path: documentPath, blocked_host_or_token: blockedHost };
  const fingerprint = buildFingerprint(fingerprintContext, policy);
  const issues = {
    outside_report_window: Number.isNaN(received) || received < Date.parse(policy.report_start_utc) || received >= Date.parse(policy.report_end_utc)
      ? report.received_at_utc : '',
    unknown_release: !releaseArtifacts.releases[report.release_id] ? report.release_id : '',
    report_only: report.disposition !== 'enforce' ? report.disposition : '',
    ignored_directive: policy.ignored_directives.includes(report.effective_directive) ? report.effective_directive : '',
    allowed_blocked_host: policy.allowed_blocked_hosts.includes(blockedHost) ? blockedHost : '',
    duplicate_fingerprint: seenFingerprints.has(fingerprint) ? seenFingerprints.get(fingerprint) : ''
  };
  const reason = policy.suppression_reason_order.find((candidate) => Boolean(issues[candidate])) ?? '';
  if (reason) {
    suppressedRows.push({ line_no: lineNo, report_id: report.report_id, reason, detail: issues[reason] });
    continue;
  }

  seenFingerprints.set(fingerprint, report.report_id);
  const mapKey = `${report.release_id}\0${report.source_file}\0${report.line_number}\0${report.column_number}`;
  const source = sourceMappings.get(mapKey) ?? {
    source_path: '', source_line: '', source_column: '', function_name: '', symbol: ''
  };
  const severity = policy.severity_by_directive[report.effective_directive] ?? 'medium';
  normalizedRows.push({
    report_id: report.report_id,
    fingerprint,
    release_id: report.release_id,
    document_path: documentPath,
    effective_directive: report.effective_directive,
    blocked_host_or_token: blockedHost,
    severity,
    source_path: source.source_path,
    function_name: source.function_name,
    received_at_utc: report.received_at_utc
  });
  sourceRows.push({
    report_id: report.report_id,
    release_id: report.release_id,
    source_file: report.source_file,
    generated_line: report.line_number,
    generated_column: report.column_number,
    source_path: source.source_path,
    source_line: source.source_line,
    source_column: source.source_column,
    function_name: source.function_name,
    symbol: source.symbol
  });
}

normalizedRows.sort((left, right) => left.report_id.localeCompare(right.report_id));
sourceRows.sort((left, right) => left.report_id.localeCompare(right.report_id));
suppressedRows.sort((left, right) => Number(left.line_no) - Number(right.line_no));

const rollups = new Map();
for (const row of normalizedRows) {
  const current = rollups.get(row.fingerprint) ?? {
    fingerprint: row.fingerprint,
    release_id: row.release_id,
    effective_directive: row.effective_directive,
    document_path: row.document_path,
    blocked_host_or_token: row.blocked_host_or_token,
    severity: row.severity,
    first_report_id: row.report_id,
    report_count: 0,
    source_path: row.source_path,
    owner_hint: ownerFor(row.source_path, policy)
  };
  current.report_count += 1;
  rollups.set(row.fingerprint, current);
}
const alertRows = [...rollups.values()].sort((left, right) => left.first_report_id.localeCompare(right.first_report_id));

await fs.mkdir(path.join(outputRoot, 'reports'), { recursive: true });
await fs.writeFile(path.join(outputRoot, 'reports', 'normalized_violations.csv'), toCsv(
  ['report_id', 'fingerprint', 'release_id', 'document_path', 'effective_directive', 'blocked_host_or_token', 'severity', 'source_path', 'function_name', 'received_at_utc'], normalizedRows
));
await fs.writeFile(path.join(outputRoot, 'reports', 'source_lookup.csv'), toCsv(
  ['report_id', 'release_id', 'source_file', 'generated_line', 'generated_column', 'source_path', 'source_line', 'source_column', 'function_name', 'symbol'], sourceRows
));
await fs.writeFile(path.join(outputRoot, 'reports', 'suppressed_reports.csv'), toCsv(
  ['line_no', 'report_id', 'reason', 'detail'], suppressedRows
));
await fs.writeFile(path.join(outputRoot, 'reports', 'alert_rollup.csv'), toCsv(
  ['fingerprint', 'release_id', 'effective_directive', 'document_path', 'blocked_host_or_token', 'severity', 'first_report_id', 'report_count', 'source_path', 'owner_hint'], alertRows
));
