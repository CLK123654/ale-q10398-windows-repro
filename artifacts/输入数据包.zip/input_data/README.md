CSP上报离线分流

这套脱敏材料来自前端安全值班演练。data/csp_reports.jsonl保存浏览器逐行上报，其中一行内容不完整；config/release_artifacts.json关联发布版本、压缩文件与source map；source_maps目录提供简化映射；rules/csp_triage_policy.json规定时间窗口、压制顺序、指纹、严重级别及源码负责人。

在input_data根目录创建output/src/triage_csp_reports.mjs，再运行npm run process。完成版应使用Node.js内置模块读取所有材料，从本次输入生成四张CSV。Windows11、macOS和Linux使用同一命令，不需要第三方npm包、浏览器或网络连接。starter/triage_csp_reports.mjs只说明目标，不是完成版。
