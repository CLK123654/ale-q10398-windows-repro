// 读取CSP JSONL、release_artifacts与source_maps，生成规范化违例、源码定位、压制记录和告警汇总。
