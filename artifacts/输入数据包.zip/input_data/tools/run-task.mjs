import { spawnSync } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';

const inputRoot = process.cwd();
const outputRoot = path.join(inputRoot, 'output');
const candidate = path.join(outputRoot, 'src', 'triage_csp_reports.mjs');

async function cleanReports() {
  await fs.rm(path.join(outputRoot, 'reports'), { recursive: true, force: true });
}

try {
  const required = [
    'data/csp_reports.jsonl',
    'config/release_artifacts.json',
    'rules/csp_triage_policy.json',
    'starter/triage_csp_reports.mjs',
    'package.json',
    'README.md'
  ];
  for (const relative of required) {
    if (!(await fs.stat(path.join(inputRoot, relative)).catch(() => null))?.isFile()) {
      throw new Error(`缺少输入：${relative}`);
    }
  }
  if (!(await fs.stat(candidate).catch(() => null))?.isFile()) {
    throw new Error('缺少完成版：output/src/triage_csp_reports.mjs');
  }
  const releases = JSON.parse(await fs.readFile(path.join(inputRoot, 'config', 'release_artifacts.json'), 'utf8'));
  const maps = [...new Set(Object.values(releases.releases ?? {}).flatMap((release) => Object.values(release.source_maps ?? {})))];
  for (const relative of maps) {
    if (!(await fs.stat(path.join(inputRoot, relative)).catch(() => null))?.isFile()) {
      throw new Error(`缺少source map：${relative}`);
    }
  }

  await cleanReports();
  const result = spawnSync(process.execPath, [candidate, inputRoot, outputRoot], {
    cwd: inputRoot,
    encoding: 'utf8',
    timeout: 30000,
    windowsHide: true
  });
  if (result.error || result.status !== 0) {
    throw new Error(result.error?.message ?? result.stderr ?? result.stdout ?? `status=${result.status}`);
  }
  const reports = (await fs.readdir(path.join(outputRoot, 'reports'))).sort();
  const expected = ['alert_rollup.csv', 'normalized_violations.csv', 'source_lookup.csv', 'suppressed_reports.csv'];
  if (JSON.stringify(reports) !== JSON.stringify(expected)) {
    throw new Error(`报告成员不符：${reports.join('、')}`);
  }
  process.stdout.write('CSP上报分流完成\n');
} catch (error) {
  await cleanReports();
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 2;
}
